package com.load;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
