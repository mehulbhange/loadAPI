package com.load.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.load.entity.Load;
import com.load.service.LoadServiceImpl;

@RestController
public class LoadController {
	
	@Autowired
	LoadServiceImpl loadService;
	
	
	@PostMapping("/load")
	ResponseEntity<String> addLoad(@RequestBody Load load) {
		return new ResponseEntity<String>(loadService.addLoad(load),HttpStatus.OK);
	}
	
	@GetMapping("/load/{loadId}")
	ResponseEntity<Load> getLoadById(@PathVariable("loadId") long loadId) {
		return new ResponseEntity<Load>(loadService.getLoadById(loadId),HttpStatus.OK);
	}
	
	@GetMapping("/load")
	List<Load> getLoadByShipperId(@RequestParam String shipperId){
		return loadService.getLoad(shipperId);
	}
	
	@PutMapping("/load/{loadId}")
	String updateLoad(@PathVariable("loadId") long loadId, @RequestBody Load load) {
		Load updatedLoad = loadService.updateLoad(loadId, load);
		String msg = "loads details updated successfully";
		if(updatedLoad != null)
			return msg;
		else
			return null;
	}
	
	@DeleteMapping("/load/{loadId}")
	void deleteLoad(@PathVariable("loadId") long loadId) {
		loadService.deleteLoad(loadId);
	}
	
	
}
